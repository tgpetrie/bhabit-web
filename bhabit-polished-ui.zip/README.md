# BHABIT UI (Polished Version)

Fully styled React-based site with grid layout, navigation, animations, and whitepaper integration.

## Install

```bash
npm install
```

## Run

```bash
npm start
```

## Build

```bash
npm run build
```